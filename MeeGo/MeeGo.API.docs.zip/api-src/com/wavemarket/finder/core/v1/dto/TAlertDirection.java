package com.wavemarket.finder.core.v1.dto;

/**
 * @author oliver
 */

/*
 * Created-Date: Jul 8, 2008
 * Created-Time: 11:47:17 AM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TAlertDirection implements java.io.Serializable {

   INSIDE,
   OUTSIDE,
   INSIDE_OUTSIDE;
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   tab-width: 3
**   indent-tabs-mode: nil
** End:
**
** ex: set softtabstop=3 tabstop=3 expandtab cindent shiftwidth=3
*/
