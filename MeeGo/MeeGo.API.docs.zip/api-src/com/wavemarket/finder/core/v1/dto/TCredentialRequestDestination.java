package com.wavemarket.finder.core.v1.dto;

public enum TCredentialRequestDestination {
   WAP,
   WEB,
   IPHONE;
}
