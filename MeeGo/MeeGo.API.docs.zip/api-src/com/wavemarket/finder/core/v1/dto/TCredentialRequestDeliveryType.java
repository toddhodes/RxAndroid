package com.wavemarket.finder.core.v1.dto;

public enum TCredentialRequestDeliveryType {
   EMAIL,
   SMS,
   PUSH_NOTIFICATION;
}
