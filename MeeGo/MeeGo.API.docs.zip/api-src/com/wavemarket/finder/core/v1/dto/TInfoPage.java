package com.wavemarket.finder.core.v1.dto;

public enum TInfoPage {
   TOS,
   CANCEL;
}
