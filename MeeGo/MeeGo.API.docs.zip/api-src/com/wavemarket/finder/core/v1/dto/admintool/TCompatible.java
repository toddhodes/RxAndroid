package com.wavemarket.finder.core.v1.dto.admintool;

/**
 * @author oliver
 */

/*
 * Created-Date: May 12, 2008
 * Created-Time: 4:47:13 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TCompatible implements java.io.Serializable {
   COMPATIBLE,
   NOT_COMPATIBLE,
   UNKNOWN;
}
