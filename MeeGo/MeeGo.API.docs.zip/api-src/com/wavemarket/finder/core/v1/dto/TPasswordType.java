package com.wavemarket.finder.core.v1.dto;

/**
 * @author oliver
 */

/*
 * Created-Date: Jul 25, 2008
 * Created-Time: 6:39:40 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TPasswordType {
   ALPHA,
   NUMERIC,
   ALPHANUMERIC;
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   indent-tabs-mode: nil
** End:
*/