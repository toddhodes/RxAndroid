package com.wavemarket.finder.core.v1.dto.location;

/**
 * @author oliver
 */

/*
 * Created-Date: May 16, 2008
 * Created-Time: 11:59:33 AM
 * Copyright 2007 WaveMarket, Inc 
 */
public class TLandmarkInfo implements java.io.Serializable {
   public TLandmarkInfo() {
      // auto-generated
   }
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   indent-tabs-mode: nil
** End:
*/

