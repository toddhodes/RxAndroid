package com.wavemarket.finder.core.v1.dto;

public enum TCredentialRequestType {
   PASSWORD,
   TOKEN
}
