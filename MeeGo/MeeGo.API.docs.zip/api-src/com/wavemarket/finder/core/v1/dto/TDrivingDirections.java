package com.wavemarket.finder.core.v1.dto;

/**
 * @author oliver
 */

/*
 * Created-Date: Apr 7, 2008
 * Created-Time: 3:43:11 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public class TDrivingDirections implements java.io.Serializable {
   public TDrivingDirections() {
      // auto-generated
   }
   // who knows what goes here?
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   indent-tabs-mode: nil
** End:
*/

