package com.wavemarket.finder.core.v1.dto.signup;

public enum TDemoAccountState implements java.io.Serializable {
   PENDING,
   REJECTED,
   APPROVED,
   NO_ACCOUNT;
}