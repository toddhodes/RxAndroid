package com.wavemarket.finder.core.v1.dto;

public enum TPaymentAccountType implements java.io.Serializable {
	MRC, PAYG
}