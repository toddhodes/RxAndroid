package com.wavemarket.finder.core.v1.dto.signup;

import java.io.Serializable;


public enum TSignupType implements Serializable {
    REGULAR_SIGNUP,
        DEMO_SIGNUP,
        TEMP_PASSWORD_SIGNUP,
        ADMINTOOL_SIGNUP,
        EMAIL_PASSWORD_SIGNUP;
   
}


