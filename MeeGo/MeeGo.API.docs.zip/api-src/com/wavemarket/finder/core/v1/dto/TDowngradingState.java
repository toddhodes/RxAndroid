package com.wavemarket.finder.core.v1.dto;

public enum TDowngradingState implements java.io.Serializable {
   NEEDS_DOWNGRADING,
   FORCED_DOWNGRADED,
   DOESNT_NEED_DOWNGRADING;
}
