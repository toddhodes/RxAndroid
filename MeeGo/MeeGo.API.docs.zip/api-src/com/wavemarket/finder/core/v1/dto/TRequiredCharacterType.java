package com.wavemarket.finder.core.v1.dto;

/**
 * @author oliver
 */

/*
 * Created-Date: Jul 29, 2008
 * Created-Time: 6:47:04 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TRequiredCharacterType {
   ALPHA,
   NUMERIC,
   SYMBOL,
   UPPERCASE_ALPHA,
   LOWERCASE_ALPHA;
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   indent-tabs-mode: nil
** End:
*/