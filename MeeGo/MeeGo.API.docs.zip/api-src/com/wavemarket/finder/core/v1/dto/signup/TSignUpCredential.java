package com.wavemarket.finder.core.v1.dto.signup;

import com.wavemarket.finder.core.v1.dto.TCredential;

/**
 * @author oliver
 */

/*
 * Created-Date: Jun 25, 2008
 * Created-Time: 10:57:30 AM
 * Copyright 2007 WaveMarket, Inc 
 */
public interface TSignUpCredential extends TCredential {
}

/*
** Local Variables:
**   mode: java
**   c-basic-offset: 3
**   indent-tabs-mode: nil
** End:
*/

