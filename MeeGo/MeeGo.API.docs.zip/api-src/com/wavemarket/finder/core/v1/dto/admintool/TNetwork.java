package com.wavemarket.finder.core.v1.dto.admintool;

/**
 * @author oliver
 */

/*
 * Created-Date: May 12, 2008
 * Created-Time: 3:25:07 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TNetwork implements java.io.Serializable {
   COULD_NOT_DETERMINE,
   DONT_CARE,
   IDEN,
   CDMA,
   AT_T,
   ALLTEL,
   VERIZON,
   T_MOBILE,
   VIVO,
   BELL,
   KAJEET,
   NOT_A_CELL;
}
