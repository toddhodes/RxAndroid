package com.wavemarket.finder.core.v1.dto.admintool;

/**
 * @author oliver
 */

/*
 * Created-Date: May 12, 2008
 * Created-Time: 4:44:52 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TPhoneStatus implements java.io.Serializable {
   SUSPENDED,
   ACTIVE,
   TERMINATED,
   N_A,
   STATUS_UNAVAILABLE
}
