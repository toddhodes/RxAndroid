package com.wavemarket.finder.core.v1.dto;

public enum TCredentialRequestPurpose {
   SIGNUP,
   DEMO_SIGNUP,
   RESET_PASSWORD,
   UNPROVISIONED_ACCOUNT;   
}
