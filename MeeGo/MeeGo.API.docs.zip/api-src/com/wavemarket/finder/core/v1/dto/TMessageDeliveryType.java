package com.wavemarket.finder.core.v1.dto;

/**
 * @author oliver
 */

/*
 * Created-Date: Apr 7, 2008
 * Created-Time: 3:40:54 PM
 * Copyright 2007 WaveMarket, Inc 
 */
public enum TMessageDeliveryType implements java.io.Serializable {
   EMAIL,
   SMS,
   SMS_AND_EMAIL,
   DO_NOT_DELIVER
}
