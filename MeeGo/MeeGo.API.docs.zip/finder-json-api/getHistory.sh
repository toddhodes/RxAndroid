cat getHistory.json | POST -sS "http://meego.location-labs.com:8080/finder-att-family/finderApiJson.svc?method=getLocationHistory&service=history&v=1"

