cat loc.json | POST -sS "http://meego.location-labs.com:8080/finder-att-family/finderApiJson.svc?method=requestLocation&service=location&v=1"

