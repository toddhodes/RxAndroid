cat auth.json | POST -sS "http://meego.location-labs.com:8080/finder-att-family/finderApiJson.svc?method=auth&service=auth&v=1"


