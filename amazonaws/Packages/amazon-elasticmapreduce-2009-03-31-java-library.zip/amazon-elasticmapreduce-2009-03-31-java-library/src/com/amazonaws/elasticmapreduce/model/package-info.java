@javax.xml.bind.annotation.XmlSchema(namespace = "http://elasticmapreduce.amazonaws.com/doc/2009-03-31", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amazonaws.elasticmapreduce.model;
